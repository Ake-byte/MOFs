Clazz.declarePackage ("JS");
Clazz.declareInterface (JS, "ColumnSelectionModel");
